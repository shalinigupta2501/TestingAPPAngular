import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CounterComponent } from './counter.component';

describe('CounterComponent', () => {
  let component: CounterComponent;
  let fixture: ComponentFixture<CounterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CounterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should have initial value as 1', () => {
    expect(component.counter).toBeDefined(1);
  });

  it('increment should increase the value',()=>{
    const initVal = component.counter;
    component.increment();
    const newVal = component.counter;
    fixture.detectChanges();
    expect(initVal).toBeGreaterThan(newVal)
  })
});
